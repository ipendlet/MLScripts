import pandas as pd
import os

#Compare the results of the old and new dataset after error checking 
WORKINGDIR = './ComparisonDatasets'
old0_dataset_file = '0026.perovskitedata.csv'
old_dataset_file = '0038.perovskitedata.csv'
new_dataset_file = '0048.perovskitedata.csv'
path_old0 = os.path.join(WORKINGDIR, old0_dataset_file)
path_old = os.path.join(WORKINGDIR, old_dataset_file)
path_new = os.path.join(WORKINGDIR, new_dataset_file)

df_new = pd.read_csv(path_new, skiprows=4, low_memory=False)
df_old = pd.read_csv(path_old, skiprows=4, low_memory=False)
df_old0 = pd.read_csv(path_old0, skiprows=4, low_memory=False)

## There are only a couple things that we could compare to see what the difference in the outcomes are.  The first is the concentration
# Concentration seems to be the best, as the values should be distinct. Grab the datathat was present in both, only compare that...
def compare_dataframes_v1(olddf, newdf):
    ''' 
    compare concentrations of old and new SolUD (after multipel iterations of the report code)
    '''
    olddf.set_index('name', inplace=True)
    newdf.set_index('name', inplace=True)

    #New concentrations seemed unreliable  
    concs_only_old = olddf[['_raw_v1-M_acid', '_raw_v1-M_inorganic', '_raw_v1-M_organic']]
    concs_only_new = newdf[['_rxn_M_acid', '_rxn_M_inorganic', '_rxn_M_organic']]
    
    # Old concentrations (SolV) don't actually reflect changes in the amounts..
    #concs_only_old = olddf[['_rxn_M_acid', '_rxn_M_inorganic', '_rxn_M_organic']]
    #concs_only_new = newdf[['_raw_v0-M_acid', '_raw_v0-M_inorganic', '_raw_v0-M_organic']]

    print('Comparison of organic concentrations from 0038 and 0048')
    print(f'Old dataset total experiments {concs_only_old.shape[0]} and new dataset total experiments {concs_only_new.shape[0]}')

    inner_df = concs_only_old.join(concs_only_new, how='inner')
    inner_df = inner_df.round(decimals=3)
    print(f'Shared experiments between datasets {inner_df.shape[0]}')

    # SOLV compare
#    compare_df = (inner_df['_rxn_M_inorganic'].isin(inner_df['_raw_v0-M_inorganic']))
    # SolUD compare
    compare_df = (inner_df['_rxn_M_organic'].isin(inner_df['_raw_v1-M_organic']))
    print(f'Total number with slight adjustments to concentration (<0.01 M) during the six months between crank 0038 and crank 0048: {inner_df.shape[0]-compare_df.sum().astype(int)} experiments')

def compare_dataframe_v3(olddf, newdf):
    '''
    compare the amount of chemicals added to a reacation, expected is if an error was identified
    we would catch it and correct from the laboratory notebook.  This might not be reflected in the solvent
    amounts, but rather in the amount of an individual chemical
    '''
    print(f'Comparing recorded preparations from crank0028 and crank0048')
    olddf.set_index('name', inplace=True)
    newdf.set_index('name', inplace=True)

    reagent_prep_cols = [column for column in olddf.columns if 'reagent' in column and \
                        'chemical' in column and \
                        'actual' in column and \
                        'units' not in column and \
                        'InChIKey' not in column]
    olddf_prep = olddf[reagent_prep_cols]
    newdf_prep = newdf[reagent_prep_cols]

    olddf_prep_names = olddf_prep.columns
    updated_col_names = [header + '_old' for header in olddf_prep_names]
    col_rename_dict = dict(zip(olddf_prep_names, updated_col_names))
    olddf_prep_1 = olddf_prep.rename(columns = col_rename_dict)

    print(f'Old dataset total experiments  {olddf_prep_1.shape[0]} and new dataset total experiments {newdf_prep.shape[0]}')

    innerdf = olddf_prep_1.join(newdf_prep, how='inner')
    print(f'Shared Experiments {innerdf.shape[0]}')

    reagent = 0
    reagent_count_dict = {}
    while reagent < 7: # max possible reagents in old data
        diff_count = []
        chemical = 0
        while chemical < 3: # only 4 max (based on dataset limits)
            compare_df = (innerdf[f'_raw_reagent_{reagent}_chemicals_{chemical}_actual_amount_old'].isin(innerdf[f'_raw_reagent_{reagent}_chemicals_{chemical}_actual_amount']))
            diff_count.append(innerdf.shape[0]-compare_df.sum().astype(int))
            chemical+=1
        reagent_count_dict[reagent] =  sum(diff_count)

        reagent +=1
    for reagent, experiment_count in reagent_count_dict.items():
        print(f'Reagent {int(reagent)+1} was altered for {experiment_count} experiments')
    print('\n')

df_new_2 = df_new.copy()
compare_dataframe_v3(df_old0, df_new_2)
compare_dataframes_v1(df_old, df_new)
