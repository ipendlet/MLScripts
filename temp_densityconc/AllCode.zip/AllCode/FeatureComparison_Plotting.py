#%%
### Start analysis of feature data
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import os

#WORKINGDIR = '/Users/ipendleton/HaverDrive/DARPA SD2 Perovskites/Dissemination/Publications/2019-07_Improving_Concentration/2 - Supplementary Information/5 Targeted Feature Assessment/GBT'
WORKINGDIR = '/Users/ipendleton/HaverDrive/DARPA SD2 Perovskites/Dissemination/Publications/2019-07_Improving_Concentration/2 - Supplementary Information/5 Targeted Feature Assessment/OHGBT'
featn = os.path.join(WORKINGDIR, 'Features_named_importance.csv')
featv = os.path.join(WORKINGDIR, 'Features_value_importance.csv')

#n is name, v is values
featn_df = pd.read_csv(featn)
featv_df = pd.read_csv(featv)

# Grab first 10 most important features from each case we care about
featn_df.rename({'Unnamed: 0': 'UID'}, inplace=True, axis=1)
featn_df.set_index('UID',inplace=True)
featn_df = featn_df.iloc[:,:20]
featn_df = featn_df.apply(lambda x: x.str.strip() if x.dtype == "object" else x) # strip white spaces from names

featv_df.rename({'Unnamed: 0': 'UID'}, inplace=True, axis=1)
featv_df.set_index('UID',inplace=True)
featv_df = featv_df.iloc[:,:20].astype(float)

#normalize the feature importance across the selected dataframe
sumv_df = (featv_df.sum(axis=1))
featv_norm_df = featv_df.divide(sumv_df,axis='index')

featnames = ['noConc.raw1', 'data1.raw1', 'data1', 'data0']

def find_unique(df_feat_name):
    '''
    returns set of entries from df
    '''
    feats_unique = []
    for column in df_feat_name.columns:
        uniques = df_feat_name[column].unique()
        for unique in uniques:
            feats_unique.append(unique)
    feats_unique = list(set(feats_unique))
    return feats_unique


rename_dict = {"data0.raw1": "SolV + Chem",
    "data1.raw1": "SolUD + Chem",
    "data0.raw2": "SolV + Exp",
    "data1.raw2": "SolUD + Exp",
    "data0.raw3": "SolV + Reag",
    "data1.raw3": "SolUD + Reag",
    "data0": "SolV",
    "data1": "SolUD",
    "data1.pM": "SolUD (prop.)",
    "noConc.raw1": "Chem",
    "noConc.raw2": "Exp",
    "noConc.raw3": "Reagent",
    "noConc": "Feats<sup>*</sup> Only"}

feat_rename_dict = {"'_feat_ASA-'":"Avg Surface Area",
                   "'_raw_reagent_0_volume'":"Solvent Dispense Vol.",
                   "'_raw_reagent_1_volume'":"Inorganic Dispense Vol.",
                   "'_raw_reagent_2_volume'":"Organic Dispense Vol.",
                   "'_raw_reagent_3_volume'":"Inorganic Dispense Vol. 2",
                   "'_raw_reagent_4_volume'":"Organic Dispense Vol. 2",
                   "'_raw_reagent_5_volume'":"Acid Dispense 1",
                   "'_raw_reagent_6_volume'":"Acid Dispense 2",
                   "'_rxn_M_acid'":"Acid Conc. (SolUD)",
                   "'_rxn_M_organic'":"Org. Conc. (SolUD)",
                   "'_rxn_M_organic'":"Org. Conc. (SolUD)",
                   "'_raw_v0-M_acid'":"Acid Conc. (SolV)",
                   "'_raw_v0-M_inorganic'":"Inorg. Conc. (SolV)",
                   "'_raw_reagent_2_chemicals_0_actual_amount'":"Mass Organoammonium",
                   "'_rxn_proportionalConc_v1-organic'":"Org. Conc. Ratio",
                   "'_rxn_M_inorganic'":"Inorg. Conc. (SolUD)",
                   "'_raw_v0-M_organic'":"Org. Conc. (SolV)",
                   "'_rxn_proportionalConc_v1-inorganic'":"Inorg. Conc. Ratio",
                   "'_feat_VanderWaalsSurfaceArea'":"Org. Surface Area",
                   "'_feat_Aliphatic AtomCount'":"# Aliphatic Atoms",
                   "'_feat_MinimalProjectionRadius'":"Org. Min. Radius",
                   "'_feat_ASA_P'":"Polar Surface Area",
                   "'_onehot_ZEVRFFCPALTVDN-UHFFFAOYSA-N'":"O.H. CyMeNH<sub>3</sub>",
                   "'_onehot_LLWRXQXPJMPHLR-UHFFFAOYSA-N'":"O.H. MeNH<sub>3</sub>",
                   "'_onehot_QHJPGANWSLEMTI-UHFFFAOYSA-N'":"O.H. Formamidinium",
                   "'_feat_MinimalProjectionArea'":"Min. Projection Area"
                   }

df_contributions_dict = {}
for feat_name in featnames:
    feat_name_df = featn_df[[f'{feat_name}_' in row for row in featn_df.index]]
    feat_values_df = featv_norm_df[[f'{feat_name}_' in row for row in featv_norm_df.index]]
    unique_feats = find_unique(feat_name_df)
    nameslist = []
    valuelist = []
    for unique_feat in unique_feats:
        feat_value_total = []
        for column in feat_name_df.columns:
        #print(feat_name_df.loc[feat_name_df[column] == ([unique_feats[13]])])
            feat_value_total.extend(feat_values_df.loc[feat_name_df[column] == unique_feat, [column]].sum(axis='columns').values.tolist())
        nameslist.append(unique_feat)
        valuelist.append(sum(feat_value_total))
    sum_feat_contributions = pd.DataFrame.from_dict({'name': nameslist, 'value': valuelist})
    df_contributions_dict[rename_dict[feat_name]] = sum_feat_contributions


for key in df_contributions_dict.keys():
    df_contributions_dict[key].sort_values(by='value',ascending=False, inplace=True)
    df_contributions_dict[key].reset_index(inplace=True, drop=True)
#    print(df_contributions_dict[key].iloc[:20,:])


def my_flexible_layout(feat_name, df, count):
    layout = go.Layout(
                      paper_bgcolor='#FFFFFF',
                      plot_bgcolor='#FFFFFF',
                      height=500,
                      width=200,
                      autosize=False,
                      title=dict(
                          text=f"{feat_name}",
                          x=0.54,
                          y=0.98,
                          font=dict(
                                family='Arial',
                                size=26, 
                                color='#0f0f0f')
                          ), 
                     xaxis=dict(
 #                             title='Feature Name',
                              gridcolor='#FFFFFF',
                              mirror=True,
                              showline=True,
                              automargin=False,
 #                             ticks='inside',
 #                             ticklen=10,
 #                             tickwidth=2.0, 
                              tickcolor='black', 
                              linewidth=3.0, 
                              linecolor='black', 
                              tickangle=90,
                              tickfont=dict(
                                      family='Arial',
                                      size=20,
                                      color='black'
                              ),
                              titlefont=dict(
                                      family='Arial',
                                      size=28,
                                      color='black'),
                      ),
                      yaxis=dict(
 #                             title='Normalized Contribution to Model',
                              gridcolor='#FFFFFF',
                              ticks = 'inside',
                              range=[0,2.0],
                              ticklen = 10,
                              tickwidth = 3.0,
                              tickcolor='black',
                              showline=True,
                              automargin=False,
                              mirror=True,
                              linewidth=3.0,
                              linecolor='black',
                              tickformat = ".1f",
                              tickfont= dict(
                                      family='Arial',
                                      size=20,
                                      color='black'
                              ),
                              titlefont=dict(
                                  family='Arial',
                                  size=28,
                                  color='black')
                      ),
                      margin=dict( 
                            l=35,
                            b=235,
                            r=3,
                            t=40),
                      showlegend=False
    )

    yvals = df['value']
    xvals = df['name']
    myplot = go.Bar(x=xvals, y=yvals,
                    marker_color='teal',
                    name=feat_name
#                    xaxis=f'x{plotitem[0]}',
#                    yaxis=f'y{plotitem[1]}'
    )
    fig = go.Figure(data=[myplot], layout=layout)
    fig.write_image(f"FeatureContribution_{count}_sample.pdf")
    #iplot(fig)
#    fig.show()

#unique_plot_list = []  
count=0
for feat_set in df_contributions_dict.keys():
    my_feat_df = df_contributions_dict[feat_set].iloc[:5,:]
    my_feat_df.replace(feat_rename_dict, inplace=True)
    my_feat_df.to_csv(f'{feat_set}.csv')
    my_flexible_layout(feat_set, my_feat_df,count)
    count+=1
    #unique_plot_list.extend(df_contributions_dict[feat_set].iloc[:7,0].unique())

#uniquefeatures = (sorted(list(set(unique_plot_list))))


# %%
