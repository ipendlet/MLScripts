#Plotting Functions for regenerating publication ready figures
#%%
#Setup
import pandas as pd 
import os

from sklearn.linear_model import LinearRegression
import plotly.graph_objs as go
from plotly.offline import iplot
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from math import sqrt
import psutil
pd.set_option('display.max_rows', 500)

#%%
#Import dataframes

WORKINGDIR = '/Users/ipendleton/HaverDrive/DARPA SD2 Perovskites/Dissemination/Publications/2019-07_Improving_Concentration/2 - Supplementary Information/2 Observed Solution Volume'
dataset_file = 'Observed_Sol_Vol_V3_curated.csv'
path = os.path.join(WORKINGDIR, dataset_file)

df = pd.read_csv(path)
#df['Halonium Coloring'] = "#267B8C" 
#Cl_density_df['Halonium Coloring'] = "#E99C34" 
#Br_density_df['Halonium Coloring'] = "#9B2C2E"

namecolumns = ['Observed', 'SolV', 'SolUD-','SolUD']
all_reagents_df = df[namecolumns]


print(all_reagents_df.shape)
metricsdict = {}
#%%
def density_plot_all(x_1,
                     x_2,
                     x_3,
                     target_y,
                     all_reagents_df,
                     title):
    '''
    :param density_df: input dataframe with "Calculated Density (g/cm^3)" and "Experimental Density' density
    :autofit: bool, toggles use of range_x and range_y
    :range_x: list with two values [min,max] for x axis
    :range_y: list with two values [min,max] for y axis
    :name: name of plot in header and in file

    :return: scores, returns plotted function to fully calculated decimal
    '''
    feature_list = ['SolV', 'SolUD-', 'SolUD']

    y = all_reagents_df[['Observed']]

    def flat_predictions(predictions_list):
        flat_pred_list= [item for sublist in predictions_list for item in sublist]
        return flat_pred_list

    for name in feature_list:
        x = all_reagents_df[[name]]
        linear_regress = LinearRegression().fit(x, y)
        r2 = (linear_regress.score(x, y))
        fullline = ('y = %sx + %s' %(linear_regress.coef_[0][0], linear_regress.intercept_[0]))
        prettyline = ('y = %sx + %s' %(round(linear_regress.coef_[0][0], 2), (round(linear_regress.intercept_[0], 2))))
        out = "r2 = " + str(r2) + "\n" + str(fullline)

        metricsdict[name] = {}
        predicted = linear_regress.predict(x)
        metricsdict[name]['pred'] = flat_predictions(predicted)
        actual = y
        metricsdict[name]['r2'] = r2_score(actual,predicted, multioutput='uniform_average')
        metricsdict[name]['rmse'] = sqrt(mean_squared_error(actual,predicted))
        metricsdict[name]['mae'] = mean_absolute_error(actual,predicted)
        metricsdict[name]['prettyline'] = prettyline


    p1 = go.Scatter(y=target_y,
                    x=x_1,
                    mode='markers',
                    name='SolV',
                    marker=dict(
                        color = "#4177bc", 
                        size=10,
                        symbol='square')
    )

    p2 = go.Scatter(y=target_y,
                    x=x_2,
                    mode='markers',
                    name='SolUD<sub>Mol</sub>',
                    marker=dict(
                        color = '#F2D91D', 
                        size=10)
    )

    p3 = go.Scatter(y=target_y, 
                    x=x_3,
                    mode='markers',
                    name='SolUD',
                    marker=dict(
                        color = '#C32742', 
                        size=10)
    )

    # plot identity
    p6 = go.Scatter(y=target_y, 
                    x=target_y,
                    yaxis='y2',
                    xaxis='x2',
                    mode='markers',
                    name ='Identity',
                    showlegend=False,
                    opacity=0
                    )

    p4 = go.Scatter(y=target_y, 
                    x=target_y,
                    mode='lines',
                    name ='Identity',
                    showlegend=True,
                    line=dict(color='black', width=4)
                    )

    p5 = go.Scatter(y = metricsdict['SolUD']['pred'], 
                    x = x_3,
                    mode='lines',
                    name='SolUD Fit',
                    showlegend=True,
                    line=dict(color='red',
                              dash='dot',
                              width=4)
                    )

    layout = go.Layout(
                      paper_bgcolor='#FFFFFF',
                      plot_bgcolor='#FFFFFF',
                      height=600,
                      width=700,
                      title=dict(
                          text=title,
                          x = 0.5,
                          y = 0.95,
                          font=dict(
                              family='Arial',
                              size=32,
                              color='#0f0f0f')),
                      xaxis2=dict(
                              range=[0,95], 
                              overlaying='x',
                              ticks='inside',
                              ticklen=5,
                              tickwidth=1.5,
                              tickcolor='black',
                              showticklabels=False,
                              tickvals=list(range(1,95,1))
                      ),
                      yaxis2=dict(
                              range=[0,95], 
                              overlaying='y',
                              ticks='inside',
                              ticklen=5,
                              tickwidth=1.5,
                              tickcolor='black',
                              showticklabels=False,
                              tickvals=list(range(1,95,1))
                      ),
                      xaxis=dict(
                              range=[0,95],
                              title='Calculated Reagent Volume (mL)',
                              showgrid=False,
                              showline=True,
                              mirror=True,
                              ticks='inside',
                              ticklen=10,
                              tickwidth=3.0,
                              tickcolor='black',
                              linewidth=4.0,
                              linecolor='#000000',
                              titlefont=dict(
                                      family='Arial',
                                      size=28,
                                      color='#0f0f0f'),
                              tickfont=dict(
                                      family='Arial',
                                      size=24,
                                      color='black'
                              ),
                              tickformat='.0f',
                              tickvals=list(range(0,95,10))
                      ),
                      yaxis=dict(
                              range=[0,95], 
                              title='Observed Reagent Volume (mL)',
                              gridcolor='#FFFFFF',
                              showline=True,
                              mirror=True,
                              ticks='inside',
                              ticklen=10,
                              tickwidth=3.0,
                              tickcolor='black',
                              linewidth=4.0,
                              linecolor='#000000',
                              titlefont=dict(
                                  family='Arial',
                                  size=28,
                                  color='#0f0f0f'),                    
                              tickfont=dict(
                                      family='Arial',
                                      size=24,
                                      color='black'
                              ),
                              tickformat='.0f',
                              tickvals=list(range(10,95,10))
                      ),
                      margin=dict( 
                            l=40,
                            b=40,
                            r=40,
                            t=80),
                      annotations=[dict(
                          y=87,
                          x=6,
                          xanchor="left",
                          yanchor="top",
                          text=f"SolUD Metrics:<br> R<sup>2</sup> = {round(metricsdict['SolUD']['r2'], 3)} <br> {metricsdict['SolUD']['prettyline']}",
                          showarrow=False,
                          font = dict(
                             color='black',
                             size = 24,
                             family='Arial'
                          )
                      )],
                      showlegend=True,
                      legend=dict(
                          y=0.10,
                          x=0.64,
                          bgcolor = 'white',
                          font = dict(
                             color='black',
                             size = 24,
                             family='Arial'
                          )
                      )
            ) 
    fig = go.Figure(data=[p6, p1, p3, p4], layout=layout)
#    iplot(fig)
    pdf_title = f"{title}.pdf"
    path = os.path.join(WORKINGDIR, pdf_title)
    fig.write_image(path)
    return metricsdict

metricsdict = density_plot_all(all_reagents_df['SolV'],
                all_reagents_df['SolUD-'],
                all_reagents_df['SolUD'],
                all_reagents_df['Observed'],
                all_reagents_df,
                'Comparison of Model Calculated Volumes')


#%%
df_metrics = pd.DataFrame(metricsdict)
outmetric = os.path.join(WORKINGDIR, 'outmetrics.csv')
df_metrics.to_csv(outmetric)
#%%
## Do some similar analysis
import os
import pandas as pd 

WORKINGDIR = '/Users/ipendleton/HaverDrive/DARPA SD2 Perovskites/Dissemination/Publications/2019-07_Improving_Concentration/2 - Supplementary Information/'
maindataset = '4 Crystallization Prediction by Machine Learning/0045.perovskitedata.csv'
inventory = '3 Non-ideal mixing/Chemical Inventory.xlsx'

inventoryfile = os.path.join(WORKINGDIR, inventory)
myfile = os.path.join(WORKINGDIR, maindataset)
main_df = pd.read_csv(myfile, skiprows=4)
main_df = main_df[main_df['_raw_ExpVer'] == 1.1].reset_index(drop=True)
# only reaction that use GBL as a solvent (1:1 comparisons -- DMF and other solvents could convolute analysis)    
main_df = main_df[main_df['_raw_reagent_0_chemicals_0_InChIKey'] == "YEJRWHAVMIAJKC-UHFFFAOYSA-N"].reset_index(drop=True)    

# removes some anomalous entries with dimethyl ammonium still listed as the organic.
main_df = main_df[main_df['_rxn_organic-inchikey'] != 'JMXLWMIFDJCGBV-UHFFFAOYSA-N'].reset_index(drop=True)
#%%
def calculate_percent_error(df, col_list):
    df_new = pd.DataFrame()
    df_new['diff'] = (df.loc[:,col_list[0]] - df.loc[:,col_list[1]]) 
    df_new['error'] = (df_new['diff'] / df.loc[:,col_list[1]])
    df_new = pd.concat([df_new, df], axis=1)
    df_new.set_index('name', inplace=True)
    return(df_new)

def print_inorg_error_analysis(new_df, names_thing):
    print(f"Reporting statistics for {names_thing}")
    print(f"Max Error Index: {new_df[['error']].idxmax()} Value: {new_df['error'].max()}")
    print('')
    print(f"Min Error Index: {new_df[['error']].idxmin()} Value: {new_df['error'].min()}")
    print('')
    print(f"Mean Error Value: {new_df['error'].mean()}")
    print(f"Error Std Value: {new_df['error'].std()}")
    print('\n')

inorganic_list = ['_raw_v0-M_inorganic', '_rxn_M_inorganic']
organic_list = ['_raw_v0-M_organic', '_rxn_M_organic']

inorg_diff_df = calculate_percent_error(main_df, inorganic_list)
print_inorg_error_analysis(inorg_diff_df, 'inorg')

org_diff_df = calculate_percent_error(main_df, organic_list)
print_inorg_error_analysis(org_diff_df, 'org')
#%%
chem_df = pd.read_excel(inventoryfile)
#chem_df.columns
smol_df = chem_df[['Chemical Category', 'Chemical Name', 'Density            (g/mL)']]
smol_df.sort_values(by=['Density            (g/mL)'], inplace=True)
smol_df.to_csv('BIGTHING.csv')

#%%
#### 
#
# %%
