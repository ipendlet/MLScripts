#%%
import sklearn
import numpy as np
import pandas as pd
import plotly as py
import plotly.graph_objs as go
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline

#%%
df = pd.read_csv('3 Non-ideal mixing/MolFractionResults.csv')

#%%
x = df['FAH Mole Fraction_0'].tolist()
y = df['Ve'].tolist()

#model = Pipeline([('poly', PolynomialFeatures(degree=3)), 
#                  ('linear', LinearRegression(fit_intercept=False))])

x_2 = np.array(x).reshape(-1,1)
polynomial_features= PolynomialFeatures(degree=3)
x_poly = polynomial_features.fit_transform(x_2)

model = LinearRegression()
model.fit(x_poly, y)

y_poly_pred = model.predict(x_poly)
coeflist = model.coef_
prettyfit = (f'y = {round(coeflist[0], 2)} + {round(coeflist[1],2)}x - {round(abs(coeflist[2]),2)}x<sup>2</sup> + {round(coeflist[3],2)}x<sup>3</sup>')

rmse = np.sqrt(mean_squared_error(y,y_poly_pred))
r2 = r2_score(y,y_poly_pred)
metrics = (f'RMSE = {round(rmse, 4)} <br> R<sup>2</sup> = {round(r2, 4)}')
print(prettyfit)

#%%

# calculate polynomial
z = np.polyfit(x, y, 3)
f = np.poly1d(z)
# calculate new x's and y's
x_new = np.linspace(x[0], x[-1], 50)
y_new = f(x_new)

# Creating the dataset, and generating the plot
trace1 = go.Scatter(
                  x=x,
                  y=y,
                  mode='markers',
                  marker=go.Marker(color='#C32742', size=14),
                  name='Data'
                  )

trace2 = go.Scatter(
                  x=x_new,
                  y=y_new,
                  mode='lines',
                  marker=go.Marker(color='black'),
                  name='Fit'
                  )
trace3 = go.Scatter(
                x=[0.2, 0.4, 0.55],
                y=[1.33328,1.33328,1.33328],
                mode='lines',
                line=dict(dash='dash'),
                marker=go.Marker(color='black'),
                name = 'max'

)

layout = go.Layout(
                    paper_bgcolor='#FFFFFF',
                    plot_bgcolor='#FFFFFF',
                    height=600,
                    width=700,
                    title=dict(
                        text='GBL + FAH Excess Molar Volumes',
                        x = 0.5,
                        y = 0.98,
                        font=dict(
                            family='Arial',
                            size=32,
                            color='#0f0f0f')),
                    xaxis=dict(
            #                 range=range_x,
                            title='Mole Fraction FAH (<i>x<sub>f</sub></i>)',
                            gridcolor='#FFFFFF',
                            showline=True,
                            mirror=True,
                            linecolor='#0f0f0f',
                            titlefont=dict(
                                    family='Arial',
                                    size=28,
                                    color='#0f0f0f'),
                            tickfont=dict(
                                    family='Arial',
                                    size=24,
                                    color='black'
                            ),
                            tickformat='.1f',
        #                  dtick=(range_x[1]-range_x[0])/6
                    ),
                    yaxis=dict(
            #                 range=range_y, 
                            title='Excess Molar Volume, <i>V<sub>m</sub><sup>E</sup></i> (mL/mol)',
                            gridcolor='#FFFFFF',
                            showline=True,
                            mirror=True,
                            linecolor='#0f0f0f',
                            titlefont=dict(
                                family='Arial',
                                size=28,
                                color='#0f0f0f'),                    
                            tickfont=dict(
                                    family='Arial',
                                    size=24,
                                    color='black'
                            ),
                            tickformat='.1f'
#                            dtick=20
                    ),
                    margin=dict( 
                        l=40,
                        b=40,
                        r=40,
                        t=80),
                    annotations=[
                        dict(
                        y=0.2,
                        x=0.07,
                        xanchor="left",
                        yanchor="bottom",
                        text=f'{metrics} <br> {prettyfit}',
                        showarrow=False,
                        font = dict(
                            size = 24,
                            color = 'black',
                            family='Arial'
                        )),
                        dict(
                        y=1.33328,
                        x=0.56,
                        xanchor="left",
                        yanchor="middle",
                        text='Max <i>V<sub>m</sub><sup>E</sup></i> at (0.36, 1.33)',
                        showarrow=False,
                        font = dict(
                            size = 24,
                            color = 'black',
                            family='Arial'
                        ))
                    ],
                    showlegend=False,
                    legend=dict(
                        y=0.10,
                        x=0.6,
                        bgcolor = 'white',
                        font = dict(
                            size = 24,
                            family='Arial'
                        )
                    )
        ) 

data = [trace1, trace2, trace3]
fig = go.Figure(data=data, layout=layout)
fig.write_image('3 Non-ideal mixing/Polynomial-Fit-in-python.pdf')

# %%
