# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# %% Change working directory from the workspace root to the ipynb file location. Turn this addition off with the DataScience.changeDirOnImportExport setting
# %%
import pandas as pd
import os

import graphviz
from sklearn import tree
import plotly.graph_objects as go
import plotly.figure_factory as ff
from sklearn import metrics
from sklearn.feature_selection import f_classif
from sklearn.model_selection import cross_val_score



# %%
WORKINGDIR = '/Users/ipendleton/HaverDrive/DARPA SD2 Perovskites/Dissemination/Publications/2019-07_Improving_Concentration/2 - Supplementary Information/5 Targeted Feature Assessment/'
df_path = os.path.join(WORKINGDIR, '0045.perovskitedata.csv')
df = pd.read_csv(df_path, skiprows=4)


# %%
# Curate the dataframe
# how many unique values for the top important surface area feature?
len(df['_feat_ASA-'].unique())

curated_cols = [column for column in df.columns if '_feat_' in column]
curated_df = df[curated_cols]
curated_df.drop(labels=['_feat_ChiralCenterCount', '_feat_fr_ArN', '_feat_fr_dihydropyridine'], axis=1, inplace=True)
X = curated_df



# %%

covar_df = X.corr()
zlist =  []
for index, row in covar_df.iterrows():
    zlist.append(row.tolist())

fig = go.Figure()

layout = go.Layout(
                          paper_bgcolor='#FFFFFF',
                          plot_bgcolor='#FFFFFF',
                          height=1200,
                          width=1300,
                          title=dict(
                              text= "Feature Covariance Matrix",
                              x = 0.75,
                              y = 0.97,
                              font=dict(
                                  family='Arial',
                                  size=38,
                                  color='#0f0f0f')),
                          xaxis=dict(
                                  tickangle=90,
                                  tickfont= dict(
                                          family='Arial',
                                          size=10,
                                          color='black'
                                  )),
                          yaxis=dict(
                                  tickfont= dict(
                                          family='Arial',
                                          size=10,
                                          color='black'
                                  )),
                          margin=dict( 
                                l=40,
                                b=40,
                                r=40,
                                t=80),
                          showlegend=False,
                          legend=dict(
                              y=0.03,
                              x=0.50,
                              bgcolor = 'white',
                              font = dict(
                                 size = 32,
                                 family='Arial',
                                 color='Black'
                              )
                          )
                ) 

p1 = go.Heatmap(colorscale='Viridis',
                z=zlist,
                x=X.columns.tolist(),
                y=X.columns.tolist())


fig = go.Figure(data=[p1], layout=layout)
fig.write_image("Feature_Covariance_Matrix.pdf")
fig
#%% 
# Some df operations testing
df_test = df.copy()
#print(list(df_test.columns))
vol_cols = [column for column in df.columns if '_raw_reagent_' in column and '_volume' in column and 'instructions' not in column]
df_test.drop(columns=vol_cols, inplace=True)
print(list(df_test.columns))

#%%
import plotly.graph_objects as go

vol_cols = [column for column in df.columns if '_raw_reagent_' in column and '_volume' in column and 'instructions' not in column]

conc_cols = [x for x in df.columns if '_M_' in x and 'final' not in x]
conc_cols2 = [x for x in df.columns if '_v0-M_' in x]

conc_cols.extend(conc_cols2)
conc_cols.extend(vol_cols)

all_cols = conc_cols
all_cols.append('name')
#for item in all_cols:
#        print(f"'{item}'")

#Force order for clarity
all_cols_full = ['_rxn_M_acid', '_raw_v0-M_acid', '_raw_reagent_5_volume',\
'_raw_reagent_6_volume', '_rxn_M_inorganic', '_raw_v0-M_inorganic',\
'_raw_reagent_1_volume', '_raw_reagent_3_volume', '_rxn_M_organic',\
'_raw_v0-M_organic', '_raw_reagent_2_volume', '_raw_reagent_4_volume',\
'_raw_reagent_0_volume', 'name']

all_cols = ['_rxn_M_acid', '_raw_v0-M_acid', '_raw_reagent_5_volume',\
'_raw_reagent_6_volume', '_rxn_M_inorganic', '_raw_v0-M_inorganic',\
'_raw_reagent_1_volume', '_rxn_M_organic',\
'_raw_v0-M_organic', '_raw_reagent_2_volume', 'name']


curated_df = df[all_cols]
curated_df.set_index(['name'], inplace=True)

feat_rename_dict = {"'_feat_ASA-'":"Avg Surface Area",
                   "'_raw_reagent_0_volume'":"Solvent Dispense Vol.",
                   "'_raw_reagent_1_volume'":"Inorganic Dispense Vol.",
                   "'_raw_reagent_2_chemicals_0_actual_amount'":"Mass Organoammonium",
                   "'_raw_reagent_2_volume'":"Organic Dispense Vol.",
                   "'_raw_reagent_3_volume'":"Inorganic Dispense Vol. 2",
                   "'_raw_reagent_4_volume'":"Organic Dispense Vol. 2",
                   "'_raw_reagent_5_volume'":"Acid Dispense 1",
                   "'_raw_reagent_6_volume'":"Acid Dispense 2",
                   "'_rxn_M_acid'":"Acid Conc. (SolUD)",
                   "'_rxn_M_organic'":"Org. Conc. (SolUD)",
                   "'_rxn_M_organic'":"Org. Conc. (SolUD)",
                   "'_raw_v0-M_acid'":"Acid Conc. (SolV)",
                   "'_raw_v0-M_inorganic'":"Inorg. Conc. (SolV)",
                   "'_rxn_proportionalConc_v1-organic'":"Org. Conc. Ratio",
                   "'_raw_reagent_1_volume'":"Inorganic Dispense Vol.",
                   "'_rxn_M_inorganic'":"Inorg. Conc. (SolUD)",
                   "'_raw_v0-M_organic'":"Org. Conc. (SolV)",
                   "'_rxn_proportionalConc_v1-inorganic'":"Inorg. Conc. Ratio",
                   "'_feat_VanderWaalsSurfaceArea'":"Org. Surface Area",
                   "'_feat_Aliphatic AtomCount'":"# Aliphatic Atoms",
                   "'_feat_MinimalProjectionRadius'":"Org. Min. Radius",
                   "'_feat_ASA_P'":"Polar Surface Area",
                   "'_onehot_ZEVRFFCPALTVDN-UHFFFAOYSA-N'":"O.H. CyMeNH<sub>3</sub>",
                   "'_onehot_LLWRXQXPJMPHLR-UHFFFAOYSA-N'":"O.H. MeNH<sub>3</sub>",
                   "'_onehot_QHJPGANWSLEMTI-UHFFFAOYSA-N'":"O.H. Formamidinium",
                   "'_feat_MinimalProjectionArea'":"Min. Projection Area"
                   }

columns = curated_df.columns
curated_rename = {}
for column in columns:
        curated_rename[column] = feat_rename_dict[f"'{column}'"]
X = curated_df.rename(curated_rename, axis=1)
print(X.columns)
#%%
covar_df = X.corr()
covar_df = covar_df.round(decimals=2)
zlist =  []
for index, row in covar_df.iterrows():
    zlist.append(row.tolist())

fig = go.Figure()

layout = go.Layout(
                          paper_bgcolor='#FFFFFF',
                          plot_bgcolor='#FFFFFF',
                          height=400,
                          width=450
                          )
#                          title=dict(
#                              text= "",#Conc-Vol Covariance Matrix",
#                              x = 0.55,
#                              y = 0.97,
#                              font=dict(
#                                  family='Arial',
#                                  size=24,
#                                  color='#0f0f0f')),
#                          xaxis=dict(
#                                  tickangle=90,
#                                  tickfont= dict(
#                                          family='Arial',
#                                          size=11,
#                                          color='black'
#                                  )),
#                          yaxis=dict(
#                                  tickfont= dict(
#                                          family='Arial',
#                                          size=11,
#                                          color='black'
#                                  )),
#                          margin=dict( 
#                                l=40,
#                                b=40,
#                                r=10,
#                                t=40),
#                          showlegend=False,
#                          legend=dict(
#                              y=0.03,
#                              x=0.50,
#                              bgcolor = 'white',
#                              font = dict(
#                                 size = 32,
#                                 family='Arial',
#                                 color='Black'
#                              )
#                          )
#                ) 

p1 = ff.create_annotated_heatmap(
                zlist,
                x=X.columns.tolist(),
                y=X.columns.tolist(),
                colorscale='Viridis'
#                colorbar=dict(
#                    thickness=20,
#                    tickfont=dict(
#                             size = 12,
#                             family='Arial',
#                             color='Black'
#                             ),
#                    tickformat='.1f',
#                    tickvals=[-0.4, +0.0, 0.5, 1.0]
#                ),
)


#fig = go.Figure(data=[p1], layout=layout)
p1.update_layout(
        autosize=False,
        width=650,
        height=600,
        xaxis=dict(
         tickangle=90,
          tickfont= dict(
           family='Arial',
           size=16,
           color='black'
          )
        ),
        yaxis=dict(
          tickfont= dict(
           family='Arial',
           size=16,
           color='black'
          )
        )
)
for i in range(len(p1.layout.annotations)):
        p1.layout.annotations[i].font.size=12
p1.show()
p1.write_image("Volume_concentration_Matrix.pdf")
#fig

# %%
